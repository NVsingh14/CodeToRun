
  //Ajax Post
  $(document).ready(function(){
    $("#butsave").click(function(){
        var name = $("#name").val();
        var email = $("#email").val();
        var course = $("#course").val();
        

          if( name!="" && email!="" && course!="")
          {

            $.ajax({
              type: "POST",
              url: "<?php echo base_url('/index.php/AjaxController/savedata'); ?>",
              datatype: 'html',
              data: {name: name, email: email, course: course},
              success: function(res)
              {
                //alert(res);
                  if(res == 1)
                  {
                    alert('data inserted successfully');
                    $("#name").val('');
                    $("#email").val('');
                    $("#course").val('');
                  }
                  else
                  {
                    alert('data not saved');
                  }
              }, //success module ends here
              error:function()
              {
                alert('data not saved')
              }

            }); //ajax function ends here
          }
          else
          {
            alert('please fill all fields first');
          }
    }); //butsave function ends here
  });
