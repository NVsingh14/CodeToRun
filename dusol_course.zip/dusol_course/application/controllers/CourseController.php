<?php
class CourseController extends CI_Controller{
public function __construct()
	{
		parent::__construct();

		$this->load->database();

		$this->load->model('CourseModel');
	}
	public function index()
	{
		
		$this->load->view('home');
	}

	public function history_3rd_sem()
	{
		$d['sol']=$this->input->get('sol');//'18-1-02-010752';
		$this->load->view('history_3rd_sem',$d);
	}

	public function mcom_3rd_sem()
	{	
		$mcom_rollno['mcom_rollno']='18-1-02-010752';
		$this->load->view('mcom_3rd_sem');
	}

	public function hindi_3rd_sem()
	{
		$hindi_rollno['sol'] = $this->input->get('sol');
		$this->load->view('hindi_3rd_sem',$hindi_rollno);
	}

	public function sanskrit_3rd_sem()
	{
		$sanskrit_rollno['sol'] = $this->input->get('sol');
		$this->load->view('sanskrit_3rd_sem',$sanskrit_rollno);
	}

	public function pol_sci_3rd_sem()
	{
		$pol_rollno['sol'] = $this->input->get('sol');
		$this->load->view('pol_sci_3rd_sem',$pol_rollno);
	}

	public function savedata()
	{
		$paper_one=$paper_two=$paper_three=$paper_four='';
		$table='course_ma_hist';
		$get_val=$this->input->post('value');
		$sol_roll_no=$this->input->post('sol_roll_no');
		$email =$this->input->post('email');


			for($i=0;$i<count($get_val);$i++)
			{
				if($i==0)
				{
					$paper_one = $get_val[0];
				}
				if($i==1)
				{
					$paper_two=$get_val[1];
				}
				if($i==2)
				{
					$paper_three = $get_val[2];
				}
				if($i==3)
				{
					$paper_four=$get_val[3];
				}
				else
				{
					$paper_four='';
				}

			}
		
		$data=array(
			'paper_one'=>$paper_one,
			'paper_two'=>$paper_two,
			'paper_three'=>$paper_three,
			'paper_four'=>$paper_four,
			'email'=>$email,
			'sol_roll_no'=>$sol_roll_no,

		);
		if(!empty($sol_roll_no) && !empty($email))
		$this->CourseModel->insert_data($table,$data);
	}


	public function savedata_hindi_3rd_sem()
	{
		$paper_one=$this->input->post('paper_one');
		$paper_two=$this->input->post('paper_two');
		$paper_three=$this->input->post('paper_three');
		$paper_four=$this->input->post('paper_four');
		$paper_five=$this->input->post('paper_five');
		$sol_roll_no = $this->input->post('sol_roll_no');

		if(!empty($sol_roll_no) )

			$table='course_ma_hindi';

			$data=array(
			'paper_one'=>$paper_one,
			'paper_two'=>$paper_two,
			'paper_three'=>$paper_three,
			'paper_four'=>$paper_four,
			'paper_five'=>$paper_five,
			'sol_roll_no'=>$sol_roll_no,

			);
			$this->CourseModel->insert_data($table,$data);

	}

	public function savedata_sanskrit_3rd_sem()
	{
		$paper_one=$this->input->post('paper_one');
		$paper_two=$this->input->post('paper_two');
		$paper_three=$this->input->post('paper_three');
		$paper_four=$this->input->post('paper_four');
		$sol_roll_no = $this->input->post('sol_roll_no');
		$email = $this->input->post('email');

		if(!empty($sol_roll_no) && !empty($email) )

			$table='course_ma_sanskrit';

			$data=array(
			'paper_one'=>$paper_one,
			'paper_two'=>$paper_two,
			'paper_three'=>$paper_three,
			'paper_four'=>$paper_four,
			'email'=>$email,
			'sol_roll_no'=>$sol_roll_no,

			);
			$this->CourseModel->insert_data($table,$data);

	}


	public function testhello()
	{
	
		$r = implode(',', $this->input->get());
		echo $r;

		
	}
	
}
?>