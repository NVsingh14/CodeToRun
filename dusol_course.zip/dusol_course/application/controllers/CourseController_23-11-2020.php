<?php
class CourseController extends CI_Controller{
public function __construct()
	{
		parent::__construct();

		$this->load->database();

		$this->load->model('CourseModel');
	}
	public function index()
	{
		//$d['id']='18-1-02-010752';
		//$this->load->view('course_form',$d);
		echo "Hello Test Page";
	}

	public function history_3rd_sem()
	{
		$d['sol']='18-1-02-010752';
		$this->load->view('history_3rd_sem',$d);
	}

	public function mcom_3rd_sem()
	{	
		$mcom_rollno['mcom_rollno']='18-1-02-010752';
		$this->load->view('mcom_3rd_sem');
	}

	public function savedata()
	{
		//echo $this->input->post('sol_roll_no');exit;
		$paper_1=$paper_2=$paper_3=$paper_4='';
		$table='course_ma_hist';
		$get_val=$this->input->post('value');
		$sol_roll_no=$this->input->post('sol_roll_no');
			for($i=0;$i<count($get_val);$i++)
			{
				if($i==0)
				{
					$paper_one = $get_val[0];
				}
				if($i==1)
				{
					$paper_two=$get_val[1];
				}
				if($i==2)
				{
					$paper_three = $get_val[2];
				}
				if($i==3)
				{
					$paper_four=$get_val[3];
				}
				else
				{
					$paper_four='';
				}

			}

			echo $paper_one."------".$paper_two."-----".$paper_three."-----".$paper_four."---".$sol_roll_no;exit;
		
		$data=array(
			'paper_one'=>$paper_one,
			'paper_two'=>$paper_two,
			'paper_three'=>$paper_three,
			'paper_four'=>$paper_four,
			'sol_roll_no'=>$sol_roll_no,

		);
		print_r($data);exit;
		$this->CourseModel->insert_data($table,$data);
	}
}
?>