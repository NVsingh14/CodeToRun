<?php 
class CourseModel extends CI_Model {

	public function insert_data($table,$data)
	{

		$condition = "sol_roll_no =" . "'" . $this->db->escape_str($data['sol_roll_no']) . "' ";
		$this->db->select('sol_roll_no');
		$this->db->from($table);
		$this->db->where($condition);
		$this->db->limit(1);
		$query = $this->db->get();
		$row=$query->result();
		if ($row) {
		echo "2";
		} else {
		$q=$this->db->insert($table,$data);

		if($q){
		 echo "1";	
		}
		else
		{
		echo "0";
			
		}
				}

	}
}
?>