<?php 
class CourseModel extends CI_Model {

	public function insert_data($table,$data)
	{
		
		$q=$this->db->insert($table,$data);

		if($q){
		 echo "1";	
		}
		else
		{
			echo "0";
			
		}
	}
}
?>