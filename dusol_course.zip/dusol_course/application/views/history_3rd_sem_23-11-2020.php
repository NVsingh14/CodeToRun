<!DOCTYPE html>
<html>
<head>
<title>DEPARTMENT OF HISTORY,DELHI UNIVERSITY</title>
<link rel="shortcut icon"  href="<?= base_url('assets/img/du_logo.png');?>" sizes="16*16">
	<div class="container">
		<img width="80" height="80" src="<?= base_url('assets/img/du_logo.png')?>" class="img-responsive" alt="School of Open Learning">
	</div>
<link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/bootstrap.min.css');?>">
</head>

<body>

<script type="text/javascript"> var base_url='<?php echo base_url();?>';</script>
<div class="container" style="padding: 2% 0 0 5%;">
	<div align="center"><legend>DEPARTMENT OF HISTORY,DELHI UNIVERSITY</legend></div>
	<div align="center"><legend>M.A.FINAL SEMESTER-III</legend></div>
	<div align="center"><legend>2020-2021 ACADEMIC YEAR</legend></div>
</div>
<div class="container">
		<h2>COURSE SELECTION : For Sol Roll Number - <?php echo $sol; ?></h2>
		<form id="form_box">
		<div align="center"><legend>Group A: HISTORY OF ANCIENT INDIA</legend></div><hr/>
		<div class="row">
			
			<input type="hidden" name="session_val" id="session_val" value="<?php echo $sol;?>">
			<div class="col-sm-3">
				<label>PAPER NO.*</label>
				<div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-a custom-control-input get_checkbox_val" data-name="Group A" id="customCheck1" value="123102301">
					      <label class="custom-control-label" for="customCheck1">123102301 (HSM 301 ELECTIVE)</label>
			    		</div>
			    </div>

			    <div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-a custom-control-input get_checkbox_val" data-name="Group A" id="customCheck2" value="123102302">
					      <label class="custom-control-label" for="customCheck2">123102302 (HSM 305 ELECTIVE)</label>
			    		</div>
			    </div>

			    <div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-a custom-control-input get_checkbox_val" data-name="Group A" id="customCheck3" value="123102303" >
					      <label class="custom-control-label" for="customCheck3">123102303 (HSM 306 Elective)</label>
			    		</div>
			    </div>

			    <div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-a custom-control-input get_checkbox_val" data-name="Group A" id="customCheck4" value="123102308">
					      <label class="custom-control-label" for="customCheck4">123102308 (HSM 312 Elective)</label>
			    		</div>
			    </div>
			    <div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-a custom-control-input get_checkbox_val" data-name="Group A" id="customCheck5" value="123102313">
					      <label class="custom-control-label" for="customCheck5">123102313 (HSM 326 Elective)</label>
			    		</div>
			    </div>

			    <div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-a custom-control-input get_checkbox_val" data-name="Group A" id="customCheck6" value="123102314">
					      <label class="custom-control-label" for="customCheck6">123102314 (HSM 329 Elective)</label>
			    		</div>
			    </div>

			</div>
			<div class="col-sm-9">
				<label>TITLE OF THE PAPER</label>
				<div class="form-group">
					<p class="text-justify">Theories and Methods in Archaeology</p>
				</div>
				<div class="form-group">
					<p class="text-justify">Imaging Ancient India: Visual Arts and Archives</p>
				</div>

				<div class="form-group">
					<p class="text-justify" >Social History of Early Indian Art and Architecture:Themes, Debates And Contexts, (ca 300 BCE To 1200 CE) </p>
				</div>
				<div class="form-group">
					<p class="text-justify">Development of Early Indian Religions and Philosophies (up to circa 500 CE)</p>
				</div>
				<div class="form-group">
					<p class="text-justify">Political Processes snd Structure of Polities in Ancient India</p>
				</div>
				<div class="form-group">
					<p class="text-justify">Religion and Society in Ancient Indian Literature and Art (CA1000 BCE to ca 300 CE) </p>
				</div>
			</div>
			

		</div>


		<div align="center" style="padding-top: 2%"><legend>Group B: HISTORY OF MEDIEVAL AND EARLY MODERN INDIA</legend></div><hr/>

		<div class="row">
			
			
			<div class="col-sm-3">
				<label>PAPER NO.*</label>
				<div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-b custom-control-input get_checkbox_val" data-name="Group B" id="customCheck7" value="123102316">
					      <label class="custom-control-label" for="customCheck7">123102316 (HSM 351 Elective)</label>
			    		</div>
			    	</div>
			    	<div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-b custom-control-input get_checkbox_val" data-name="Group B" id="customCheck8" value="123102317">
					      <label class="custom-control-label" for="customCheck8">123102317 (HSM 352 Elective)</label>
			    		</div>
			    	</div>
			    	<div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-b custom-control-input get_checkbox_val" data-name="Group B" id="customCheck9" value="123102320">
					      <label class="custom-control-label" for="customCheck9">123102320 (HSM 355 Elective)</label>
			    		</div>
			    	</div>
			    	<div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-b custom-control-input get_checkbox_val" data-name="Group B" id="customCheck10"  value="123102321">
					      <label class="custom-control-label" for="customCheck10">123102321 (HSM 356 Elective)</label>
			    		</div>
			    	</div>

			    	<div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-b custom-control-input get_checkbox_val" data-name="Group B" id="customCheck11" value="123102324">
					      <label class="custom-control-label" for="customCheck11">123102324 (HSM 359 Elective)</label>
			    		</div>
			    	</div>

			    	<div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-b custom-control-input get_checkbox_val" data-name="Group B" id="customCheck12" value="123102326">
					      <label class="custom-control-label" for="customCheck12">123102326 (HSM-361 Elective)</label>
			    		</div>
			    	</div>

			    	<div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-b custom-control-input get_checkbox_val" data-name="Group B" id="customCheck13" value="123102328">
					      <label class="custom-control-label" for="customCheck13">123102328 (HSM-363 Elective)</label>
			    		</div>
			    	</div>

			    	<div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-b custom-control-input get_checkbox_val" data-name="Group B" id="customCheck14" value="123102329">
					      <label class="custom-control-label" for="customCheck14">123102329 (HSM-364 Elective)</label>
			    		</div>
			    	</div>

			    	<div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-b custom-control-input get_checkbox_val" data-name="Group B" id="customCheck15" value="123102331">
					      <label class="custom-control-label" for="customCheck15">123102331 (HSM-366 Elective)</label>
			    		</div>
			    	</div>

			    	<div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-b custom-control-input get_checkbox_val" data-name="Group B" id="customCheck16" value="123102333">
					      <label class="custom-control-label" for="customCheck16">123102333 (HSM-370 Elective)</label>
			    		</div>
			    	</div>

			    	<div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-b custom-control-input get_checkbox_val" data-name="Group B" id="customCheck17" value="123102334">
					      <label class="custom-control-label" for="customCheck17">123102334 (HSM-372 Elective)</label>
			    		</div>
			    	</div>

			    	<div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-b custom-control-input get_checkbox_val" data-name="Group B" id="customCheck18" value="123102335">
					      <label class="custom-control-label" for="customCheck18">123102335 (HSM-375 Elective)</label>
			    		</div>
			    	</div>

			</div>
			<div class="col-sm-9">
				<label>TITLE OF THE PAPER</label>
				<div class="form-group">
					<p class="text-justify">Structures of Authority: The Delhi Sultanate and the Making of Medieval Society in North India Ca. 1200-1400</p>
				</div>
				<div class="form-group">
					<p class="text-justify">History of North India, c. 1400-1550</p>
				</div>

				<div class="form-group">
					<p class="text-justify">Religion and Society in Upper Gangetic Plain: 8th-18th Cent. </p>
				</div>
				<div class="form-group">
					<p class="text-justify">The Economic and Social History of India ca. 1200-1800</p>
				</div>
				<div class="form-group">
					<p class="text-justify">Gender Relations in Mughal India</p>
				</div>

				<div class="form-group">
					<p class="text-justify">Awadh and Northern India ca. 1500s-1860s</p>
				</div>
				<div class="form-group">
					<p class="text-justify">War, Society and Politics, ca. 1700-1840</p>
				</div>
				<div class="form-group">
					<p class="text-justify">Eastern India in Transition: Ecology, State and Culture, ca.1200-1850</p>
				</div>
				<div class="form-group">
					<p class="text-justify">Connected Empires: Mughals, Safavids and Ottomans</p>
				</div>
				<div class="form-group">
					<p class="text-justify">Forms of Historical Writing In Medieval and Early Modern India</p>
				</div>
				<div class="form-group">
					<p class="text-justify">Medieval Deccan, ca. 1300-1700</p>
				</div>
				<div class="form-group">
					<p class="text-justify">Sources of The Mughal Period: Reading and Interpreting Texts</p>
				</div>
			</div>
			
		</div>



		<div align="center" style="padding-top: 2%"><legend>Group C: HISTORY OF MODERN INDIA</legend></div><hr/>
		
		<div class="row">
			
			
			<div class="col-sm-3">
				<label>PAPER NO.*</label>
				<div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" name="options[]" class="group-c custom-control-input get_checkbox_val" data-name="Group C" id="customCheck19" value="123102338">
					      <label class="custom-control-label" for="customCheck19">123102338 (HSM 401 Elective)</label>
			    		</div>
			    	</div>
			    	<div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" name="options" class="group-c custom-control-input get_checkbox_val" data-name="Group C" id="customCheck20" value="123102339">
					      <label class="custom-control-label" for="customCheck20">123102339 (HSM 402 Elective)</label>
			    		</div>
			    	</div>
			    	<div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" name="options[]" class="group-c custom-control-input get_checkbox_val" data-name="Group C" id="customCheck21" value="123102340">
					      <label class="custom-control-label" for="customCheck21">123102340 (HSM 403 Elective)</label>
			    		</div>
			    	</div>
			    	<div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" name="options[]" class="group-c custom-control-input get_checkbox_val" data-name="Group C" id="customCheck22"  value="123102343">
					      <label class="custom-control-label" for="customCheck22">123102343 (HSM 407 Elective)</label>
			    		</div>
			    	</div>

			    	<div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" name="options[]" class="group-c custom-control-input get_checkbox_val" data-name="Group C" id="customCheck23" value="123102345">
					      <label class="custom-control-label" for="customCheck23">123102345 (HSM 409 Elective)</label>
			    		</div>
			    	</div>

			    	<div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-c custom-control-input get_checkbox_val" data-name="Group C" id="customCheck24" name="options[]" value="123102354">
					      <label class="custom-control-label" for="customCheck24">123102354 (HSM 423 Elective)</label>
			    		</div>
			    	</div>

			    	<div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" name="options[]" class="group-c custom-control-input get_checkbox_val" data-name="Group C" id="customCheck25"  value="123102355">
					      <label class="custom-control-label" for="customCheck25">123102355 (HSM 428 Elective)</label>
			    		</div>
			    	</div>

			    	<div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" name="options[]" class="group-c custom-control-input get_checkbox_val" data-name="Group C" id="customCheck26" value="123102356">
					      <label class="custom-control-label" for="customCheck26">123102356 (HSM 432 Elective)</label>
			    		</div>
			    	</div>

			</div>
			<div class="col-sm-9">
				<label>TITLE OF THE PAPER</label>
				<div class="form-group">
					<p class="text-justify">Rise of British Power in India, 1757 – 1857</p>
				</div>
				<div class="form-group">
					<p class="text-justify">Strategies of Imperial Control, 1850s to 1920s </p>
				</div>

				<div class="form-group">
					<p class="text-justify">The colonial Economy in India: 1750-1850 </p>
				</div>
				<div class="form-group">
					<p class="text-justify">Select Issues in the History of Nationalism in India, (1860-1917)</p>
				</div>
				<div class="form-group">
					<p class="text-justify">Community and Religion in Modern India </p>
				</div>
				<div class="form-group">
					<p class="text-justify">Aspects of Book History in India </p>
				</div>
				<div class="form-group">
					<p class="text-justify">Cultures of Intimacy in Colonial India </p>
				</div>
				<div class="form-group">
					<p class="text-justify">History of Modern Education in India: Social Attitudes, Colonial State and Nationalism, (late 18th to mid 20th century)</p>
				</div>
			</div>
			

		</div>


		
			<div id="message" ></div>
			<input type="button" class="btn btn-primary submit_button" name="submit" id="save_data"  value="Submit" >
	</form>
</div>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script type="text/javascript" src="<?= base_url('assets/js/bootstrap.min.js');?>"></script>
</body>
</html>

<script type="text/javascript">
	

	$(function(){
        $('#save_data').click(function(e){
          
          	
            // Check each group 
            $(':checkbox[class^="group-"]').each(function(){
            	if($('input[type="checkbox"]:checked').prop('checked')==true){
            		var checkedGroups = [];
            		 
	                var currentGroup = $('input[type="checkbox"]:checked').attr('class'); 
	                var currentClass = currentGroup.replace(/\s{2,}/g, ' ').split(' '); 
	                // If the current group hasn't been checked, check it
	                if($.inArray(currentGroup,checkedGroups) == -1){
	                    var atLeastOneChecked = $(':checkbox.' + currentClass[0] + ':checked').length > 2;
	                    
	                    if(!atLeastOneChecked){

	                    	//console.log($('input[type="checkbox"]:checked').data('name'));
	                        alert("Please ensure that at least three courses from one of group is selected.");
	                        
	                        return false;
	                    }
	                    else{
	                    	//validation pass
	                    	

	                    	var checked = 0;
							var all_val=[];
							//var val = [];
							$("input:checkbox").each(function(){
								if($(this).is(':checked')){
									checked++;
									//val[i] = $(this).val();
								}
							});

							if(checked>2)
							{
								
								if(checked>4)
								{
									alert('you are only allowed to select 4 courses');
									return false;
									
								}
								else
								{
									
									var session =$('#session_val').val();
									var checked_course= [];
									$("input[name='options[]']:checked").each(function ()
									{
									    checked_course.push(parseInt($(this).val()));
									});
									//console.log(checked_course);return false;

									
									//$( ".get_checkbox_val" ).each(function( index ) {
										//console.log($(this).val()+'--');return false;
										if($(this).is(':checked')){
											//console.log(checked_course);return false;
					                       var data={'value':checked_course,'sol_roll_no':session};
					                       //console.log(data);//return false;

					                         $.ajax({
									              type: "POST",
									              url: base_url+"CourseController/savedata",
									              datatype: 'html',
									              data: data,
									              success: function(result)
									              {	console.log(result);
										                if(result==1)

											            $(".get_checkbox_val").prop("checked", false);
												        $('.submit_button').hide();
												        
												         $('#message').html('<h3 class="text-success">Thank You! We Will Contact You Shortly.</h3>');

												         setTimeout(function(){   $('#message').html(''); $('.submit_button').show();}, 3000);
												         //return false;
									                  
									              }, //success module ends here
									              error:function()
									              {
									                //alert('data not saved');
									                console.log("ERROR!");
									              }

									            }); //ajax function ends here



									     	/*$.ajax({   
											type : "POST",
									     	url:base_url+"CourseController/savedata",
										  	data: data,
									     	contentType: "application/json;charset=utf-8",
										     success: function(result)
										     {
										     	//console.log(data);return false;
												//console.log('=====>'+result);
												if(result==1)

										            $(".get_checkbox_val").prop("checked", false);
											        $('.submit_button').hide();
											        
											         $('#message').html('<h3 class="text-success">Thank You! We Will Contact You Shortly.</h3>');

											         setTimeout(function(){   $('#message').html(''); $('.submit_button').show();}, 3000);
											         //return false;

												 },
									   });*/
										}

									//});

								}

							}
							else
							{
								alert('At least 3 checkbox need to be selected');
								return false;
								
							}

	                }
	                    // If we have made it this far, then this group has been checked
	                    checkedGroups.push(currentGroup);
	                }

            	}//end of if checkbox
            	 else
            	 {
            	 	alert('Please ensure that at least three option from one of group is checked');
            	 	
					return false;
            	 }
                     
            });
          
         
          
            
        });
    });
</script>