<!DOCTYPE html>
<html>
<head>
<title>DEPARTMENT OF POLITICAL SCIENCE,DELHI UNIVERSITY</title>
<link rel="shortcut icon"  href="<?= base_url('assets/img/du_logo.png');?>" sizes="16*16">
	<div class="container">
		<img width="80" height="80" src="<?= base_url('assets/img/du_logo.png')?>" class="img-responsive" alt="School of Open Learning">
	</div>
<link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/bootstrap.min.css');?>">
</head>

<body>

<script type="text/javascript"> var base_url='<?php echo base_url();?>';</script>
<div class="container" style="padding: 2% 0 0 5%;">
	<div align="center"><legend>DEPARTMENT OF POLITICAL SCIENCE,DELHI UNIVERSITY</legend></div>
	<div align="center"><legend>M.A-Semester -III</legend></div>
	<div align="center"><legend>2020-2021 ACADEMIC YEAR</legend></div>
</div>
<div class="container">
		<h2>COURSE SELECTION: For Sol Roll Number - <?php echo $sol; ?></h2><hr/>
		<form id="form_box" action="CourseController/testhello">

			
		<input type="hidden" name="sol_val" id="sol_val" value="<?php echo $sol;?>">
		<div class="row">
			<div class="col-sm-12">
				<table class="table table-hover">
					<thead></thead>
					<tbody>
						<tr>
						<td>
							<table>
								<h5>#</h5>
								<thead><th>Slot</th></thead>
								<tbody>
									<tr><td>S-1<br><br></td></tr>
									<tr><td>S-2<br><br></td></tr>
									<tr><td>S-3<br><br><br></td></tr>
									<tr><td>S-4<br><br></td></tr>
									<tr><td>S-5</td></tr>
									<tr><td>S-6</td></tr>
									<tr><td>S-7<br><br></td></tr>
									<tr><td>S-8<br><br></td></tr>
								</tbody>
							</table>
						</td>
						
						<td>
							<table>
								<thead>
									<h5>GROUP-A</h5>
									<th>Pno.</th>
									<th>Subject</th>
								</thead>
								<tbody>
									<tr>
										<td>02</td>
										<td>
											
										    <div class="custom-control custom-checkbox">
											      <input type="checkbox" name="options1" class="group-a custom-control-input get_checkbox_val_s1" data-name="Group A" id="customCheck1" value="123202302">
											      <label class="custom-control-label" for="customCheck1">123202302 (Global Justice and the South)</label>
									    	</div>
									    	<br>
									    	
				    					</td>
									</tr>

									<tr>
									 	<td>10</td>
									    <td>
										      	
									    <div class="custom-control custom-checkbox">
									      <input type="checkbox" name="options2" class="group-a custom-control-input get_checkbox_val_s2" data-name="Group A" id="customCheck2" value="123202310">
									      <label class="custom-control-label" for="customCheck2">123202310 (Dalit -Bahujan Thought)</label>
							    		</div><br>
											 
										</td>
									</tr>

									<tr>
									 	<td>22</td>
								      	<td>
									      	
											    <div class="custom-control custom-checkbox">
											      <input type="checkbox" name="options3" class="group-a custom-control-input get_checkbox_val_s3" data-name="Group A" id="customCheck3" value="123202322">
											      <label class="custom-control-label" for="customCheck3">123202322 (Comparative federalism:Theory and Practice)</label>
									    		</div><br>
										    
										</td>
									</tr>

									<tr>
								      <td>37</td>
								      <td>
									      	  
												    <div class="custom-control custom-checkbox">
												      <input type="checkbox" name="options4" class="group-a custom-control-input get_checkbox_val_s4" data-name="Group A" id="customCheck4" value="123202337">
												      <label class="custom-control-label" for="customCheck4">123202337 (State Politics in India)</label>
										    		</div><br>
											   
										</td>
								    </tr>

								    <tr>
								    	<td></td>
								    	<td>-</td>
								    </tr>


								    <tr>
								    	<td></td>
								    	<td>-</td>
								    </tr>

								    <tr>
								      <td>33</td>
								      <td>
									      	    
									    <div class="custom-control custom-checkbox">
									      <input type="checkbox" name="options7" class="group-a custom-control-input get_checkbox_val" data-name="Group A" id="customCheck5" value="123202333">
									      <label class="custom-control-label" for="customCheck5">123202333 (Development Process & Politics in India)</label>
							    		</div>
											    
										</td>
								    </tr>


								    <tr>
								    	<td></td>
								    	<td>-</td>
								    </tr>
								</tbody>
							</table>
						</td>

						

						<td>
							<table>
								<thead>
									<h5>GROUP-B</h5>
									<th>Pno.</th>
									<th>Subject</th>
								</thead>
								<tbody>
									<tr>
										<td>45</td>
										<td>
											
										    <div class="custom-control custom-checkbox">
											      <input type="checkbox" name="options1" class="group-a custom-control-input get_checkbox_val_s1" data-name="Group A" id="customCheck6" value="123202302">
											      <label class="custom-control-label" for="customCheck6">123202302 (Global Justice and the South)</label>
									    	</div>
									    	
				    					</td>
									</tr>

										    <tr>
										      <td>16</td>
										      <td>
											      	 <div class="form-group">
														    <div class="custom-control custom-checkbox">
														      <input type="checkbox" name="options2" class="group-a custom-control-input get_checkbox_val_s2" data-name="Group A" id="customCheck7" value="123202316">
														      <label class="custom-control-label" for="customCheck7">123202316 Indian Strategic Thought)</label>
												    		</div>
													    </div>
												</td>
										    </tr>

										    <tr>
										      <td>41</td>
										      <td>
											      	 <div class="form-group">
													    <div class="custom-control custom-checkbox">
													      <input type="checkbox" name="options3" class="group-a custom-control-input get_checkbox_val_s3" data-name="Group A" id="customCheck8" value="123202341">
													      <label class="custom-control-label" for="customCheck8">123202341 (Institutions, Development and Poverty)</label>
											    		</div>
												    </div>
												</td>
										    </tr>

										    <tr>
										      <td>15</td>
										      <td>
											      	<div class="form-group">
													    <div class="custom-control custom-checkbox">
													      <input type="checkbox" name="options4" class="group-a custom-control-input get_checkbox_val_s4" data-name="Group A" id="customCheck9" value="123202315">
													      <label class="custom-control-label" for="customCheck9">123202315 (Social Exclusion: Theory and Practice)</label>
											    		</div>
												    </div>
												</td>
										    </tr>
										    <tr>
										    	<td></td>
										    	<td>-</td>
										    </tr>


										    <tr>
										    	<td></td>
										    	<td>-</td>
										    </tr>

										    <tr>
										    	<td></td>
										    	<td>-<br></td>
										    </tr>


										    <tr>
										      <td>21</td>
										      <td>
											      	    <div class="form-group">
														    <div class="custom-control custom-checkbox">
														      <input type="checkbox" name="options8" class="group-a custom-control-input get_checkbox_val" data-name="Group A" id="customCheck10" value="123202321">
														      <label class="custom-control-label" for="customCheck10">123202321 (Security Studies)</label>
												    		</div>
													    </div>
												</td>
										    </tr>
								</tbody>
							</table>
						</td>

						<td>
							<table>
								<thead>
									<h5>GROUP-C</h5>
									<th>Pno.</th>
									<th>Subject</th>
								</thead>
								<tbody>
									<tr>
								      <td></td>
								      <td>
									      -<br><br>
										</td>
								    </tr>

								    <tr>
								      <td></td>
								      <td>
									      	 -<br><br>
										</td>
								    </tr>

								    <tr>
								      <td>44</td>
								      <td>
									      	<div class="form-group">
											    <div class="custom-control custom-checkbox">
											      <input type="checkbox" name="options3" class="group-a custom-control-input get_checkbox_val" data-name="Group A" id="customCheck11" value="123202344">
											      <label class="custom-control-label" for="customCheck11">123202344 (The Political in Local Governance)</label>
									    		</div>
										    </div>
										</td>
								    </tr>

								    <tr>
								      <td> </td>
								      <td>
									      	-<br><br>
										</td>
								    </tr>
								    <tr>
								    	<th> </th>
								    	<td>-</td>
								    </tr>


								    <tr>
								    	<th></th>
								    	<td>-</td>
								    </tr>

								    <tr>
								    	<th></th>
								    	<td>-<br><br></td>
								    </tr>


								    <tr>
								      <th></th>
								      <td>
									      	  -<br>
										</td>
								    </tr>
								</tbody>
							</table>
						</td>
						</tr>	
					</tbody>
				</table>
			</div>


			

		</div>

		<div class="form-group col-sm-6">
		    <div class="custom-control custom-checkbox">
		      
		      <label for="email"><legend>Email Address*</legend></label>
		      <input type="text" class="form-control" required="" name="email" id="email">
    		</div>
		</div>

				
		<div id="message" ></div>
		<input type="submit" class="btn btn-primary submit_button" name="submit" id="save_data"  value="Submit" >
	</form>
</div>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script type="text/javascript" src="<?= base_url('assets/js/bootstrap.min.js');?>"></script>
</body>
</html>

<script type="text/javascript">
	
	$('input[type="checkbox"]').on('change', function() {
    $('input[name="' + this.name + '"]').not(this).prop('checked', false);
});
</script>

