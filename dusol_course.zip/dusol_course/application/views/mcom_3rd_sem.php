<!DOCTYPE html>
<html>
<head>
<title>DEPARTMENT OF COMMERCE,DELHI UNIVERSITY</title>
<link rel="shortcut icon"  href="<?= base_url('assets/img/du_logo.png');?>" sizes="16*16">
	<div class="container">
		<img width="80" height="80" src="<?= base_url('assets/img/du_logo.png')?>" class="img-responsive" alt="School of Open Learning">
	</div>
<link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/bootstrap.min.css');?>">
</head>

<body>

<script type="text/javascript"> var base_url='<?php echo base_url();?>';</script>
<div class="container" style="padding: 2% 0 0 5%;">
	<div align="center"><legend>DEPARTMENT OF COMMERCE,DELHI UNIVERSITY</legend></div>
	<div align="center"><legend>M.Com-Semester -III</legend></div>
	<div align="center"><legend>2020-2021 ACADEMIC YEAR</legend></div>
</div>
<div class="container">
		<h2>COURSE SELECTION: </h2>
		<form id="form_box">

			
		<div align="center"><legend>Major Elective Groups.</legend></div><hr/>
		<div class="row">
			
			<legend>Accounting</legend>
			<div class="col-sm-4">

				<label>PAPER NO.*</label>

				<div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-a custom-control-input get_checkbox_val" data-name="Group A" id="customCheck1" value="324102301(MCEC01)">
					      <label class="custom-control-label" for="customCheck1">324102301 (MCEC01)</label>
			    		</div>
			    </div>

			    <div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-a custom-control-input get_checkbox_val" data-name="Group A" id="customCheck2" value="324102302">
					      <label class="custom-control-label" for="customCheck2">324102302 (MCEC02)</label>
			    		</div>
			    </div>

			    <div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-a custom-control-input get_checkbox_val" data-name="Group A" id="customCheck3" value="324102303" >
					      <label class="custom-control-label" for="customCheck3">324102303 (MCEC03)</label>
			    		</div>
			    </div>

			    <div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-a custom-control-input get_checkbox_val" data-name="Group A" id="customCheck4" value="324102304">
					      <label class="custom-control-label" for="customCheck4">324102304 (MCEC04)</label>
			    		</div>
			    </div>

			</div>
			<div class="col-sm-8">
				<label>Elective Courses</label>
				<div class="form-group">
					<p class="text-justify">Accounting Information System</p>
				</div>
				<div class="form-group">
					<p class="text-justify">Strategic Cost Analysis and Performance Evaluation</p>
				</div>

				<div class="form-group">
					<p class="text-justify" >forensic Accounting and Fraud Examination </p>
				</div>
				<div class="form-group">
					<p class="text-justify">Global Financial Reporting and Disclosure</p>
				</div>
			</div>
			

		</div>



		<div class="row">
			
			<legend>Human Resource Mangement (HRM)</legend>
			<div class="col-sm-4">

				<label>PAPER NO.*</label>

				<div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-a custom-control-input get_checkbox_val" data-name="Group A" id="customCheck5" value="324102305">
					      <label class="custom-control-label" for="customCheck5">324102305 (MCEC05)</label>
			    		</div>
			    </div>

			    <div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-a custom-control-input get_checkbox_val" data-name="Group A" id="customCheck6" value="324102306">
					      <label class="custom-control-label" for="customCheck6">324102306 (MCEC06)</label>
			    		</div>
			    </div>

			    <div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-a custom-control-input get_checkbox_val" data-name="Group A" id="customCheck7" value="324102307" >
					      <label class="custom-control-label" for="customCheck7">324102307 (MCEC07)</label>
			    		</div>
			    </div>

			    <div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-a custom-control-input get_checkbox_val" data-name="Group A" id="customCheck8" value="324102308">
					      <label class="custom-control-label" for="customCheck8">324102308 (MCEC08)</label>
			    		</div>
			    </div>

			</div>
			<div class="col-sm-8">
				<label>Elective Courses</label>
				<div class="form-group">
					<p class="text-justify">Human Resource Developmen</p>
				</div>
				<div class="form-group">
					<p class="text-justify">Strategic Human Resource Mangement</p>
				</div>

				<div class="form-group">
					<p class="text-justify" >Industrial Relations and Compesation Laws </p>
				</div>
				<div class="form-group">
					<p class="text-justify">Human Resource Analytics</p>
				</div>
			</div>
			

		</div>


		<div class="row">
			
			<legend>Finance</legend>
			<div class="col-sm-4">

				<label>PAPER NO.*</label>

				<div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-a custom-control-input get_checkbox_val" data-name="Group A" id="customCheck9" value="324102309">
					      <label class="custom-control-label" for="customCheck9">324102309 (MCEC09)</label>
			    		</div>
			    </div>

			    <div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-a custom-control-input get_checkbox_val" data-name="Group A" id="customCheck10" value="324102310">
					      <label class="custom-control-label" for="customCheck10">324102310 (MCEC10)</label>
			    		</div>
			    </div>

			    <div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-a custom-control-input get_checkbox_val" data-name="Group A" id="customCheck11" value="324102311" >
					      <label class="custom-control-label" for="customCheck11">324102311 (MCEC11)</label>
			    		</div>
			    </div>

			    <div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-a custom-control-input get_checkbox_val" data-name="Group A" id="customCheck12" value="324102312">
					      <label class="custom-control-label" for="customCheck12">324102312 (MCEC12)</label>
			    		</div>
			    </div>

			</div>
			<div class="col-sm-8">
				<label>Elective Courses</label>
				<div class="form-group">
					<p class="text-justify">Security analysis and portfolio Management</p>
				</div>
				<div class="form-group">
					<p class="text-justify">Financial Institutions and Markets</p>
				</div>

				<div class="form-group">
					<p class="text-justify" >International Financial System</p>
				</div>
				<div class="form-group">
					<p class="text-justify">International Financial Mangement</p>
				</div>
			</div>
			

		</div>

		<div class="row">
			
			<legend>Marketing</legend>
			<div class="col-sm-4">

				<label>PAPER NO.*</label>

				<div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-a custom-control-input get_checkbox_val" data-name="Group A" id="customCheck13" value="324102313">
					      <label class="custom-control-label" for="customCheck13">324102313 (MCEC13)</label>
			    		</div>
			    </div>

			    <div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-a custom-control-input get_checkbox_val" data-name="Group A" id="customCheck14" value="324102314">
					      <label class="custom-control-label" for="customCheck14">324102314 (MCEC14)</label>
			    		</div>
			    </div>

			    <div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-a custom-control-input get_checkbox_val" data-name="Group A" id="customCheck15" value="324102315" >
					      <label class="custom-control-label" for="customCheck15">324102315 (MCEC15)</label>
			    		</div>
			    </div>

			    <div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-a custom-control-input get_checkbox_val" data-name="Group A" id="customCheck16" value="324102316">
					      <label class="custom-control-label" for="customCheck16">324102316 (MCEC16)</label>
			    		</div>
			    </div>

			</div>
			<div class="col-sm-8">
				<label>Elective Courses</label>
				<div class="form-group">
					<p class="text-justify">Advertising and Sales Mangement </p>
				</div>
				<div class="form-group">
					<p class="text-justify">International Marketing Mangement</p>
				</div>

				<div class="form-group">
					<p class="text-justify" >Consumer Behaviour</p>
				</div>
				<div class="form-group">
					<p class="text-justify">Supply Chain Mangement and Logistics </p>
				</div>
			</div>
			

		</div>

		<div class="row">
			
			<legend>International Business</legend>
			<div class="col-sm-4">

				<label>PAPER NO.*</label>

				<div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-a custom-control-input get_checkbox_val" data-name="Group A" id="customCheck17" value="324102317">
					      <label class="custom-control-label" for="customCheck17">324102317 (MCEC17)</label>
			    		</div>
			    </div>

			    <div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-a custom-control-input get_checkbox_val" data-name="Group A" id="customCheck18" value="324102318">
					      <label class="custom-control-label" for="customCheck18">324102318 (MCEC18)</label>
			    		</div>
			    </div>

			    <div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-a custom-control-input get_checkbox_val" data-name="Group A" id="customCheck19" value="324102319" >
					      <label class="custom-control-label" for="customCheck19">324102319 (MCEC19)</label>
			    		</div>
			    </div>

			    <div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-a custom-control-input get_checkbox_val" data-name="Group A" id="customCheck20" value="324102320">
					      <label class="custom-control-label" for="customCheck20">324102320 (MCEC20)</label>
			    		</div>
			    </div>

			</div>
			<div class="col-sm-8">
				<label>Elective Courses</label>
				<div class="form-group">
					<p class="text-justify">Indias Foreign Trade and Investment</p>
				</div>
				<div class="form-group">
					<p class="text-justify">Export Marketing</p>
				</div>

				<div class="form-group">
					<p class="text-justify" >Exim Procedures and Documentation</p>
				</div>
				<div class="form-group">
					<p class="text-justify">International Trade Logistics </p>
				</div>
			</div>
			

		</div>


		<div align="center"><legend>Minor Elective Courses.</legend></div><hr/>

		<div class="row">
			
			<legend>Business Laws</legend>
			<div class="col-sm-4">

				<label>PAPER NO.*</label>

				<div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-a custom-control-input get_checkbox_val" data-name="Group A" id="customCheck21" value="324102321">
					      <label class="custom-control-label" for="customCheck21">324102321 (MCEC21)</label>
			    		</div>
			    </div>

			    <div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-a custom-control-input get_checkbox_val" data-name="Group A" id="customCheck22" value="324102322">
					      <label class="custom-control-label" for="customCheck22">324102322 (MCEC22)</label>
			    		</div>
			    </div>


			</div>
			<div class="col-sm-8">
				<label>Elective Courses</label>
				<div class="form-group">
					<p class="text-justify">Corporate Laws: Cases and Applications</p>
				</div>
				<div class="form-group">
					<p class="text-justify">Industrial Laws:  Cases and Implementation</p>
				</div>

			</div>
			

		</div>


		<div class="row">
			
			<legend>Taxation</legend>
			<div class="col-sm-4">

				<label>PAPER NO.*</label>

				<div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-a custom-control-input get_checkbox_val" data-name="Group A" id="customCheck23" value="324102323">
					      <label class="custom-control-label" for="customCheck23">324102323 (MCEC 23)</label>
			    		</div>
			    </div>

			    <div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-a custom-control-input get_checkbox_val" data-name="Group A" id="customCheck24" value="324102324">
					      <label class="custom-control-label" for="customCheck24">324102324 (MCEC 24)</label>
			    		</div>
			    </div>


			</div>
			<div class="col-sm-8">
				<label>Elective Courses</label>
				<div class="form-group">
					<p class="text-justify">Principles  and Practice of Taxation of Taxation </p>
				</div>
				<div class="form-group">
					<p class="text-justify">Corporate Tax Structure and Planning </p>
				</div>

			</div>
			

		</div>



		<div class="row">
			
			<legend>Banking & Insurance</legend>
			<div class="col-sm-4">

				<label>PAPER NO.*</label>

				<div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-a custom-control-input get_checkbox_val" data-name="Group A" id="customCheck25" value="324102325">
					      <label class="custom-control-label" for="customCheck25">324102325 (MCEC25)</label>
			    		</div>
			    </div>

			    <div class="form-group">
					    <div class="custom-control custom-checkbox">
					      <input type="checkbox" class="group-a custom-control-input get_checkbox_val" data-name="Group A" id="customCheck26" value="324102326">
					      <label class="custom-control-label" for="customCheck26">324102326 (MCEC15)</label>
			    		</div>
			    </div>


			</div>
			<div class="col-sm-8">
				<label>Elective Courses</label>
				<div class="form-group">
					<p class="text-justify">Banking Products and Practice</p>
				</div>
				<div class="form-group">
					<p class="text-justify">Insurance Products and Practice</p>
				</div>

			</div>
			

		</div>


		
			<div id="message" ></div>
			<input type="button" class="btn btn-primary submit_button" name="submit" id="save_data"  value="Submit" >
	</form>
</div>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script type="text/javascript" src="<?= base_url('assets/js/bootstrap.min.js');?>"></script>
</body>
</html>

<script type="text/javascript">
	
	$(function(){

		$('#save_data').click(function(e){

			alert(' ');

		})//save_data function ends here
	});//main funciton ends here
</script>

