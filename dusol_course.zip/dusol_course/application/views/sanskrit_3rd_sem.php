<!DOCTYPE html>
<html>
<head>
<title>DEPARTMENT OF SANSKRIT,DELHI UNIVERSITY</title>
<link rel="shortcut icon"  href="<?= base_url('assets/img/du_logo.png');?>" sizes="16*16">
	<div class="container">
		<img width="80" height="80" src="<?= base_url('assets/img/du_logo.png')?>" class="img-responsive" alt="School of Open Learning">
	</div>
<link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/bootstrap.min.css');?>">
</head>

<body>

<script type="text/javascript"> var base_url='<?php echo base_url();?>';</script>
<div class="container" style="padding: 2% 0 0 5%;">
	<div align="center"><legend>DEPARTMENT OF SANSKRIT,DELHI UNIVERSITY</legend></div>
	<div align="center"><legend>M.A-Semester -III</legend></div>
	<div align="center"><legend>2020-2021 ACADEMIC YEAR</legend></div>
</div>
<div class="container">
		<h2>COURSE SELECTION: For Sol Roll Number - <?php echo $sol; ?></h2><hr/>
		<form id="form_box">

			
		<input type="hidden" name="sol_val" id="sol_val" value="<?php echo $sol;?>">
		<div class="row">
			
		
			<div class="col-sm-4">

				<label>PAPER NO.</label>

				<div class="form-group">
					<input type="hidden" name="paper_code_one" id="paper_code_one" value="121301301">
					<p class="text-justify">121301301 (301)</p>
				</div>
				<div class="form-group">
					<input type="hidden" name="paper_code_two" id="paper_code_two" value="121301302">
					<p class="text-justify">121301302 (302)</p>
				</div>
				<div class="form-group">
					<input type="hidden" name="paper_code_three" id="paper_code_three" value="121302303">
					<p class="text-justify">121302303 (303C)</p>
				</div>

				<div class="form-group">
					<input type="hidden" name="paper_code_four" id="paper_code_four" value="121302312">
					<p class="text-justify">121302312 (304C)</p>
				</div>


			</div>
			<div class="col-sm-8">
				<label>Elective Courses</label>
				<div class="form-group">
					<p class="text-justify">Linguistic Analysis of Sanskrit, Translation and Laghusiddhanta-Kaumudi</p>
				</div>
				<div class="form-group">
					<p class="text-justify">Sahitya: Kadambari & Vasavadatta</p>
				</div>

				<div class="form-group">
					<p class="text-justify" >Natyasastra and Dhvanyaloka </p>
				</div>
				<div class="form-group">
					<p class="text-justify">Kavya Prakasa</p>
				</div>
			</div>
			

		</div><br>
		<div class="row">
			<div class="col-sm-6">
				<div class="form-group">
			      <label for="exampleInputEmail1"><h5>Email Address*</h5></label>
			      <input type="email"  name="email" class="form-control" id="email" placeholder="Enter Email Address">
			    </div>
			</div>

			<div class="col-sm-6">
				<div id="error_msg">
			    </div>
			</div>
		</div>



		
		<div id="message" ></div>
		<input type="button" class="btn btn-primary submit_button" name="submit" id="save_data"  value="Submit" >
	</form>
</div>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script type="text/javascript" src="<?= base_url('assets/js/bootstrap.min.js');?>"></script>
</body>
</html>

<script type="text/javascript">
	
	$(function(){

		$('#save_data').click(function(e){

			var paper_one =$('#paper_code_one').val();
			var paper_two =$('#paper_code_two').val();
			var paper_three =$('#paper_code_three').val();
			var paper_four =$('#paper_code_four').val();
			var sol_roll_no = $('#sol_val').val();
			var email = $('#email').val();
			//console.log(email);//return false;

			var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
			if(!regex.test(email)) {
				
				$('#email').css('border-color', 'red');
				
        		$('#error_msg').html('<p style="color:red">Please Enter Correct Email Address!</p>');
        	}
        	else
        	{
        		$("#email").css("border","none");
        		$('#error_msg').hide();


        		$.ajax({
	              type: "POST",
	              url: base_url+"CourseController/savedata_sanskrit_3rd_sem",
	              datatype: 'html',
	              data: {paper_one:paper_one,paper_two:paper_two,paper_three:paper_three,paper_four:paper_four,sol_roll_no:sol_roll_no,email:email},
	              success: function(result)
	              {	
		                if(result==1)
		                {	
		                	$("#email").val('');
			            	$(".get_checkbox_val").prop("checked", false);
				        	$('.submit_button').hide();
				        
				         	$('#message').html('<h3 class="text-success">Thank You! We Will Contact You Shortly.</h3>');

				         	setTimeout(function(){   $('#message').html(''); $('.submit_button').show();}, 3000);

				     	}
				     	if(result==2)
				     	{
				     		
				     		$(".get_checkbox_val").prop("checked", false);
					        $('.submit_button').hide();
					        
					         $('#message').html('<h3 class="text-danger">Already Submitted!</h3>');

				         	setTimeout(function(){   $('#message').html(''); $('.submit_button').show();}, 3000);
				     	}
				     	if(result==0)
				     	{

				     		$(".get_checkbox_val").prop("checked", false);
					        $('.submit_button').hide();
					        
					         $('#message').html('<h3 class="text-danger">ERROR!!!!</h3>');

				         	setTimeout(function(){   $('#message').html(''); $('.submit_button').show();}, 3000);
				     	}

				       
				         //return false;
	                  
	              }, //success module ends here
	              error:function()
	              {
	                //alert('data not saved');
	                console.log("ERROR!");
	              }

	            }); //ajax function ends here


        	}
			
        	//return false;
			


		})//save_data function ends here
	});//main funciton ends here
</script>

