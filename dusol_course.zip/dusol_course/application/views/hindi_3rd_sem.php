<!DOCTYPE html>
<html>
<head>
<title>DEPARTMENT OF HINDI,DELHI UNIVERSITY</title>
<link rel="shortcut icon"  href="<?= base_url('assets/img/du_logo.png');?>" sizes="16*16">
	<div class="container">
		<img width="80" height="80" src="<?= base_url('assets/img/du_logo.png')?>" class="img-responsive" alt="School of Open Learning">
	</div>
<link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/bootstrap.min.css');?>">
</head>

<body>

<script type="text/javascript"> var base_url='<?php echo base_url();?>';</script>
<div class="container" style="padding: 2% 0 0 5%;">
	<div align="center"><legend>DEPARTMENT OF HINDI,DELHI UNIVERSITY</legend></div>
	<div align="center"><legend>M.A-Semester -III</legend></div>
	<div align="center"><legend>2020-2021 ACADEMIC YEAR</legend></div>
</div>
<div class="container">
		<h2>COURSE SELECTION: For Sol Roll Number - <?php echo $sol; ?></h2><hr/>
		<form id="form_box">

			
		<input type="hidden" name="sol_val" id="sol_val" value="<?php echo $sol;?>">
		<div class="row">
			
		
			<div class="col-sm-4">

				<label>PAPER NO.</label>

				<div class="form-group">
					<input type="hidden" name="paper_code_one" id="paper_code_one" value="120501301">
					<p class="text-justify">120501301 (301)</p>
				</div>
				<div class="form-group">
					<input type="hidden" name="paper_code_two" id="paper_code_two" value="120501302">
					<p class="text-justify">120501302 (302)</p>
				</div>
				<div class="form-group">
					<input type="hidden" name="paper_code_three" id="paper_code_three" value="120501303">
					<p class="text-justify">120501303 (303)</p>
				</div>

				<div class="form-group">
					<input type="hidden" name="paper_code_four" id="paper_code_four" value="120501304">
					<p class="text-justify">120501304 (304)</p>
				</div>

				<div class="form-group">
					<input type="hidden" name="paper_code_five" id="paper_code_five" value="120501305">
					<p class="text-justify">120501305 (305)</p>
				</div>


			</div>
			<div class="col-sm-8">
				<label>Elective Courses</label>
				<div class="form-group">
					<p class="text-justify">Aadhunik Hindi Kavya-II</p>
				</div>
				<div class="form-group">
					<p class="text-justify">Hindi Aalochana</p>
				</div>

				<div class="form-group">
					<p class="text-justify" >Hindi ke Anay Gadhay Rup </p>
				</div>
				<div class="form-group">
					<p class="text-justify">Hindi Sahitya ka Etihaas</p>
				</div>
				<div class="form-group">
					<p class="text-justify">Paschatya Kavyashastra</p>
				</div>
			</div>
			

		</div>



		
		<div id="message" ></div>
		<input type="button" class="btn btn-primary submit_button" name="submit" id="save_data"  value="Submit" >
	</form>
</div>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script type="text/javascript" src="<?= base_url('assets/js/bootstrap.min.js');?>"></script>
</body>
</html>

<script type="text/javascript">
	
	$(function(){

		$('#save_data').click(function(e){

			var paper_one =$('#paper_code_one').val();
			var paper_two =$('#paper_code_two').val();
			var paper_three =$('#paper_code_three').val();
			var paper_four =$('#paper_code_four').val();
			var paper_five =$('#paper_code_five').val();
			var sol_roll_no = $('#sol_val').val();

			

			$.ajax({
	              type: "POST",
	              url: base_url+"CourseController/savedata_hindi_3rd_sem",
	              datatype: 'html',
	              data: {paper_one:paper_one,paper_two:paper_two,paper_three:paper_three,paper_four:paper_four,paper_five:paper_five,sol_roll_no:sol_roll_no},
	              success: function(result)
	              {	
		                if(result==1)
		                {	
			            	$(".get_checkbox_val").prop("checked", false);
				        	$('.submit_button').hide();
				        
				         	$('#message').html('<h3 class="text-success">Thank You! We Will Contact You Shortly.</h3>');

				         	setTimeout(function(){   $('#message').html(''); $('.submit_button').show();}, 3000);
				     	}
				     	if(result==2)
				     	{
				     		$(".get_checkbox_val").prop("checked", false);
					        $('.submit_button').hide();
					        
					         $('#message').html('<h3 class="text-danger">Already Submitted!</h3>');

				         	setTimeout(function(){   $('#message').html(''); $('.submit_button').show();}, 3000);
				     	}
				     	if(result==0)
				     	{
				     		$(".get_checkbox_val").prop("checked", false);
					        $('.submit_button').hide();
					        
					         $('#message').html('<h3 class="text-danger">ERROR!!!!</h3>');

				         	setTimeout(function(){   $('#message').html(''); $('.submit_button').show();}, 3000);
				     	}

				       
				         //return false;
	                  
	              }, //success module ends here
	              error:function()
	              {
	                //alert('data not saved');
	                console.log("ERROR!");
	              }

	            }); //ajax function ends here


		})//save_data function ends here
	});//main funciton ends here
</script>

